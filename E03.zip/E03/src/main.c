// main.c -- Defines the C-code kernel entry point, calls initialisation routines.
//           Made for JamesM's tutorials <www.jamesmolloy.co.uk>

#include "monitor.h"
#include "descriptor_tables.h"
#include "timer.h"
#include "paging.h"

#define	__PAGE_SIZE 		0x400
#define	__PAGE_LIMIT		160
#define DEBUG						1

void swap_pages(u32int i, u32int j)
{
		// identifiers for tables and pages
		u32int ti, tj, pi, pj;
		ti 	= i / 1024; 	tj 	= j / 1024;
		pi  = i % 1024;		pj	= j % 1024;

		// content of frames
		u32int ci, cj;

		// disable paging	
		u32int cr0;
		asm volatile("mov %%cr0, %0": "=r"(cr0));
		cr0 ^= 0x80000000;
		asm volatile("mov %0, %%cr0":: "r"(cr0));

		page_directory_t *d = kernel_directory;

		ci 	= d->tables[ti]->pages[pi].frame;
		cj	= d->tables[tj]->pages[pj].frame;

		if (DEBUG)
		{
				monitor_write("[DEBUG] ci=");
				monitor_write_dec(ci);
				monitor_write(", cj=");
				monitor_write_dec(cj);
				monitor_write("\n");
		}
		
		
		d->tables[ti]->pages[pi].frame = cj;
		d->tables[tj]->pages[pj].frame = ci;

		// re-enable paging
		asm volatile("mov %%cr0, %0": "=r"(cr0));
		cr0 |= 0x80000000;
		asm volatile("mov %0, %%cr0":: "r"(cr0));

		return;		
}

int main(struct multiboot *mboot_ptr)
{
    // Initialise all the ISRs and segmentation
    init_descriptor_tables();
    // Initialise the screen (by clearing it)
    monitor_clear();

    initialise_paging();
    monitor_write("Hello, paging world!\n");

    u32int *ptr = 0x0;
		u32int i = 0;
	
		while (i<__PAGE_LIMIT)
		{
				*ptr = i;
				monitor_write("ptr: ");
				monitor_write_hex(ptr);
				monitor_write(", page: ");
				monitor_write_dec(i);
				monitor_write(" -> content: ");
				monitor_write_dec(*ptr);
				monitor_write("\n");
				ptr += __PAGE_SIZE;
				++i;
		}

		swap_pages(0, 1);
		
		ptr = 0x0;
		monitor_write("page 0 now contains: ");
		monitor_write_dec(*ptr);
		monitor_write("\n");
		ptr = 0x1000;
		monitor_write("page 1 now contains: ");
		monitor_write_dec(*ptr);
		monitor_write("\n");

    return 0;
}
